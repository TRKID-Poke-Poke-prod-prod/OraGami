# OraGami
This is made for a school project not professional and if I have copied your buisness idea, 
(can i join) Go ahead with it no copyright charges for name and stuff
# Copyright
This is all my work, if you wish to build off of it please do but give me credit.
Do not outsourse this code further
(copyright does not stand for business idea(except if you are tring to use my code for your website))